import { Injectable } from '@angular/core';
import {Subject, Observable} from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ActorService {
  private items: any[] = [{
    id: '7878787' ,
    name: 'Jhonny Deep',
  nationality: 'United States',
  birthday: '12/12'}, {
    id: '9843535' ,
    name: 'Angelina jolie',
    nationality: 'United States',
    birthday: '06/07'}, {
    id: '7034430853' ,
    name: 'Actor3',
    nationality: 'United States',
    birthday: '03/03'}, {
    id: '53049853894' ,
    name: 'Actor4',
    nationality: 'United States',
    birthday: '04/04' } ];
  private items$ = new Subject <any[]>();
  constructor() { }
  get_items() {
    return this.items;
  }
  get(id: number) {
    return this.items[id];
  }
  addItem(value: string){
    this.items.push(value);
    this.items$.next(this.items);
  }
  getitems$() {
    return this.items$.asObservable();
  }
}
