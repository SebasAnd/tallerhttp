import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-test-saas',
  templateUrl: './test-saas.component.html',
  styleUrls: ['./test-saas.component.scss']
})
export class TestSaasComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
