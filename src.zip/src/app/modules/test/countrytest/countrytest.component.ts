import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-countrytest',
  templateUrl: './countrytest.component.html',
  styleUrls: ['./countrytest.component.scss']
})
export class CountrytestComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
