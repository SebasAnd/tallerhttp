import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-categoriestest',
  templateUrl: './categoriestest.component.html',
  styleUrls: ['./categoriestest.component.scss']
})
export class CategoriestestComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
